package com.group4.card;

public interface CardRepository extends CrudRepository<Card, Integer> {

}
